//package com.ryan.storyapp
//
//class BaseApplication {
//}